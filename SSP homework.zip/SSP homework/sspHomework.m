%___________________________Generating Y
    Y=pingstats('planetlab01.cs.washington.edu',100,'v');

%___________________________Computing the optimal theta

%_____ gaussian distribution G _______
% thetaG = (uG,sigG2) 
uG = (1/100)*sum(Y)
sigG2 = 0.01*sum((Y-uG).^2)


%_____ Rayleigh distribution R _______
% thetaR = sigR2 
sigR2 = (1/200)*sum(Y.^2)

%_____ Erlang distribution Em _______
% thetaEm = Lm (for lambda) 
L = 100/sum(Y); %intermediary computation
%We then get our results for different values of m:
L0 = L
L1 = 2*L
L2=3*L

%_____ Shifted exponential distribution exp _______
% thetaexp = Lexp, aexp (for lambda and alpha) 
aexp = min(Y)
Lexp = 100/(sum(Y)-100*aexp)

%_____ Shifted Rayleigh distribution SR _______
% thetaSR =  aSR, sigSR (for alpha and sigma) 
% As there is no analytical solution, we will make an exhaustive search and
% take the best value for aSR.
aSR = (999*min(Y)/1000)*rand;
maxaSR = fun_to_maximize(Y,aSR); % intermediary value for best aSR calculus 
for c = 1:1000
    random_aSR = (999*min(Y)/1000)*rand;  %With this expression, we make sure that 0 <= random_aSR < min(Y)
    rand_maxaSR = fun_to_maximize(Y,random_aSR);
    if rand_maxaSR >= maxaSR
        aSR = random_aSR;
        maxaSR = rand_maxaSR;
    end
end

disp("aSR = "+ aSR)
sigSR = (1/200)*sum((Y-aSR).^2)



%______________________________Plot everything
x = linspace(min(Y)-0.5,max(Y)+0.1);
 G =  Gaussian(x,uG,sigG2);
 R = Rayleigh(x,sigR2);
 E0 = Erlang0(x,L0);
 E1 = Erlang0(x,L1);
 E2 = Erlang0(x,L2);
 Exp = shiftedExp(x,Lexp,aexp);
 SR = SRayleigh(x,aSR, sigSR);
 
 histY  = histogram(Y,'Normalization','probability');    
 hold on
 plot( x, G, 'Color', 'blue');
 hold on
 plot(x, R, 'Color', 'red');
 hold on
 plot(x, E0, 'Color', 'yellow');
  hold on
 plot(x, E1, 'Color', 'cyan');
  hold on
 plot(x, E2, 'Color', 'green');
   hold on
 plot(x, Exp, 'Color', 'black');
   hold on
 plot(x, SR, 'Color', 'magenta');
 
 legend('Histogram', 'Gaussian', 'Rayleigh', 'Erlang m=0','Erlang m = 1','Erlang m = 2','Shifted exponential', 'Shifted Rayleigh')
% hold off
title( 'Plot of histogram and density functions');




%Decide the best model from the log likelyhood criterion
criterionG = prod(Gaussian(Y,uG,sigG2).*100)
criterionR = prod(Rayleigh(Y,sigR2).*100)
criterionE0 = prod( Erlang0(Y,L0).*100)
criterionE1 = prod(Erlang1(Y,L1).*100)
criterionE2 = prod(Erlang2(Y,L2).*100)
criterionExp = prod(shiftedExp(Y,Lexp,aexp).*100)
criterionSR = prod(SRayleigh(Y,aSR,sigSR).*100)

%functions: 

function d = Gaussian(y,uG,sigG2) 
    d = 1/(sqrt(2*pi*sigG2))*exp(-(y-uG).^2/(2*sigG2)); 
end
function d = Rayleigh(y,sigR2) 
    d = y/(sigR2).*exp(-y.^2/(2*sigR2)); 
end
function d = Erlang0(y,L0)  
    d = L0.*exp(-y*L0); 
end
function d = Erlang1(y,L1)  
    d = L1^2.*y.*exp(-y*L1); 
end
function d = Erlang2(y,L2)  
    d = 0.5*L2^3.*y.^2.*exp(-y*L2); 
end
function d = shiftedExp(y,Lexp,aexp) 
    d = Lexp.*exp(-Lexp.*(y-aexp)); 
end
function d = SRayleigh(y,aSR,sigSR)  
    d = (y-aSR)/(sigSR).*exp(-(y-aSR).^2/(2*sigSR)); 
end
function d = fun_to_maximize(y,random_aSR)  %Helpful for exhaustive search (finding aSR)
    d = sum(log(y - random_aSR)-log(sum((y-random_aSR).^2))-(100.*(y-random_aSR).^2)/(sum((y-random_aSR).^2))); 
end
