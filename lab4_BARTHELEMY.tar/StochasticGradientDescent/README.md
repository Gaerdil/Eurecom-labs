# Stochastic Gradient Descent
Simple Notebook to work on SGD:

* First with a principled introduction
* Then with serial algorithms, 
* And finally with distributed algorithms using pyspark

