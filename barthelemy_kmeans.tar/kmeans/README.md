# kmeans
Simple Notebook to work on the k-means algorithm:

* First, with a principled introduction to k-means
* Then with a pyspark distributed implementation
